### singleton pattern

- Singleton == global vars and static functions
- Behaves like a namespace
- e.g: Renderer and random number generator
- `Singleton`模式：将每个`non-local static `对象搬到自己的专属函数内(该对象在此函数内被声明为`static`[即`local static`对象])。这些函数返回一个reference 指向它所含的对象。然后用户调用这些函数，而不直接指涉这些对象。换句话说，non-local static 对象被local static 对象替换了。

#### Meyer's singleton

```c++
#include <iostream>
#include <cstdlib>


class Random
{
public:

	Random(const Random&) = delete;

	static Random& Get() 
	{
		static Random s_Instance;
		return s_Instance;
	}
	static double Double()
	{
		return Random::Get().IDouble();
	}


private:
	double IDouble() 
	{ 
		return (double)std::rand();
	}
	Random()	
	{
		std::srand((unsigned)time(nullptr));
	}
	
};


int main()
{

	double number = Random::Double();
	std::cout << number << std::endl;
}


```





